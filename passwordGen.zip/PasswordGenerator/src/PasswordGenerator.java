import java.security.SecureRandom; 
public class PasswordGenerator {
	
		private static final String CHARACTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+-=[]{}|;':\\\"<>,.?/";

	public static void main(String[] args) {
		
		int length = 12;
		
		String password = generatePassword(length);
		System.out.println(password);
	}
	public static String generatePassword(int length) {
		SecureRandom random = new SecureRandom();
		StringBuilder sb = new StringBuilder();
		
		for (int i = 0; i < length; i++) {
			int index = random.nextInt(CHARACTERS.length());
			char c = CHARACTERS.charAt(index);
			sb.append(c); 

	}
	return sb.toString();

	}
}




