/**
 * 
 */
/**
 * @author ahmadhazem
 *
 */
module FizzBuzz1 {
}