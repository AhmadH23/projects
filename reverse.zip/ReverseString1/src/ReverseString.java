
public class ReverseString {

	public static void main(String[] args) {
		
		String str = "are you as excited as I am";
		String result = "";
		
		
		
		String[] arr= str.split("\\s");
		
		for (int i = arr.length-1; i >= 0; i--) {
			
			// i >=0 as long as i is greater than zero it will print 
			// until it reaches zero
			
			result = result + arr[i]+" ";
			// using arr to return individual words 
		}
		System.out.println(result);
	}

}
