
public class PangramChecker {

	public static void main(String[] args) {
		String s = "Sixty zippers were quickly picked from the woven jute bag";
		// this is the pangram there 
		
		boolean [] mark = new boolean[26]; // this is the size of the alphabet
		boolean pangram = true;
		int index = 0;
		// setting the variables 
		
		for (int i = 0; i < s.length(); i++) {
			
			char cur = s.charAt(i);
			// cur meaning current variable
			
			if (cur >= 'A' && cur <= 'Z') {
				index = cur - 'A';
			} else if (cur >= 'a' && cur <= 'z') {
				index = cur - 'a';
			} 
			// determining whether character is capital or not
			mark[index] = true;
			}
			
		for (int i = 0; i < mark.length; i++) {
			if(mark[i] == false) {
				pangram = false;
			}
			
		}
		if (pangram) {
			System.out.println("Its a pangram!!");
		} else {
			System.out.println("Its not a pangram :(");
		}
		//System.out.println(pangram);
		//printing this once letter is removed from string s it 
		//will print false
	}

}

